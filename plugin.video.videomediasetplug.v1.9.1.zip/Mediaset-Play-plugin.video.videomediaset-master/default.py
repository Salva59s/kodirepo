# -*- coding: utf-8 -*-
from resources.main import KodiMediaset

km = KodiMediaset()
km.main()
