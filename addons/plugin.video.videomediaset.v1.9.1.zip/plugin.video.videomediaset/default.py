# -*- coding: utf-8 -*-
from resources.lib.mediaset import Mediaset
from phate89lib import kodiutils, staticutils

useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'

mediaset = Mediaset()
mediaset.log = kodiutils.log
mediaset.setUserAgent(useragent)

def root():
    kodiutils.addListItem("Programmi TV",{'mode':'programmitv'})
    kodiutils.addListItem("Fiction",{'mode':'fiction'})
    kodiutils.addListItem("Film",{'mode':'film'})
    kodiutils.addListItem("Canali Live",{'mode':'canali_live'})
    kodiutils.endScript()

def __gather_info(prog):
    infos = {}
    infos['title']=prog["title"]
    if infos['title'] == '' and 'mediasetprogram$brandTitle' in prog:
        infos['title']=prog["mediasetprogram$brandTitle"]
    
    if 'credits' in prog:
        infos['cast']=[]
        infos['director']=[]
        for person in prog['credits']:
            if person['creditType']=='actor':
                infos['cast'].append(person['personName'])
            elif person['creditType']=='director':
                infos['director'].append(person['personName'])
    plot=""
    plotoutline=""
    #try to find plotoutline
    if 'shortDescription' in prog:
        plotoutline=prog["shortDescription"]
    elif 'mediasettvseason$shortDescription' in prog:
        plotoutline=prog["mediasettvseason$shortDescription"]
    elif 'description' in prog:
        plotoutline=prog["description"]
    elif 'mediasetprogram$brandDescription' in prog:
        plotoutline=prog["mediasetprogram$brandDescription"]
    elif 'mediasetprogram$subBrandDescription' in prog:
        plotoutline=prog["mediasetprogram$subBrandDescription"]
        
    #try to find plot
    if 'longDescription' in prog:
        plot=prog["longDescription"]
    elif 'description' in prog:
        plotoutline=prog["description"]
    elif 'mediasetprogram$brandDescription' in prog:
        plot=prog["mediasetprogram$brandDescription"]
    elif 'mediasetprogram$subBrandDescription' in prog:
        plot=prog["mediasetprogram$subBrandDescription"]
        
    #fill the other if one is empty
    if plot=="":
        plot=plotoutline
    if plotoutline=="":
        plotoutline=plot
    infos['plot'] = plot
    infos['plotoutline'] = plotoutline
    if 'mediasetprogram$duration' in prog:
        infos['duration'] = prog['mediasetprogram$duration']
    if 'mediasetprogram$genres' in prog:
        infos['genre']=prog['mediasetprogram$genres']
    elif 'mediasettvseason$genres' in prog:
        infos['genre']=prog['mediasettvseason$genres']
    if 'year' in prog:
        infos['year']=prog['year']
    if 'tvSeasonNumber' in prog:
        infos['season']=prog['tvSeasonNumber']
    if 'tvSeasonEpisodeNumber' in prog:
        infos['episode']=prog['tvSeasonEpisodeNumber']
    
    return infos
    
def __gather_art(prog):
    arts = {}
    if 'thumbnails' in prog:
        if 'image_vertical-264x396' in prog['thumbnails']:
            arts['poster'] = prog['thumbnails']['image_vertical-264x396']['url']
            arts['thumb'] = arts['poster']
        elif 'channel_logo-100x100' in prog['thumbnails']:
            arts['poster'] = prog['thumbnails']['channel_logo-100x100']['url']
            arts['thumb'] = arts['poster']
            
        if 'brand_cover-1440x513' in prog['thumbnails']:
            arts['banner'] = prog['thumbnails']['brand_cover-1440x513']['url']
        elif 'image_header_poster-1440x630' in prog['thumbnails']:
            arts['banner'] = prog['thumbnails']['image_header_poster-1440x630']['url']
        elif 'image_header_poster-1440x433' in prog['thumbnails']:
            arts['banner'] = prog['thumbnails']['image_header_poster-1440x433']['url']
        if 'image_header_poster-1440x630' in prog['thumbnails']:
            arts['landscape'] = prog['thumbnails']['image_header_poster-1440x630']['url']
        elif 'image_header_poster-1440x433' in prog['thumbnails']:
            arts['landscape'] = prog['thumbnails']['image_header_poster-1440x433']['url']
        if 'brand_logo-210x210' in prog['thumbnails']:
            arts['icon'] = prog['thumbnails']['brand_logo-210x210']['url']
    return arts

def __imposta_tipo_media(prog):
    if 'tvSeasonNumber' in prog or 'tvSeasonEpisodeNumber' in prog:
        kodiutils.setContent('episodes')
    elif 'seriesId' in prog and 'mediasetprogram$subBrandId' not in prog:
        kodiutils.setContent('tvshows')
    elif 'mediasetprogram$subBrandDescription' in prog and (prog['mediasetprogram$subBrandDescription'].lower() == 'film' or prog['mediasetprogram$subBrandDescription'].lower() == 'documentario'):
        kodiutils.setContent('movies')
    else:
        kodiutils.setContent('videos')
    
def __analizza_elenco(progs):
    if len(progs) > 0:
        __imposta_tipo_media(progs[0])
    for prog in progs:
        infos = __gather_info(prog)
        arts=__gather_art(prog)
        if 'media' in prog:
            kodiutils.addListItem(prog["title"],{'mode':'video','pid':prog['media'][0]['pid']},videoInfo=infos,arts=arts,isFolder=False)
        elif 'tuningInstruction' in prog:
            kodiutils.addListItem(prog["title"],{'mode':'live','id':prog['tuningInstruction']['urn:theplatform:tv:location:any'][1]['releasePids'][0]},videoInfo=infos,arts=arts,isFolder=False)
        elif 'mediasetprogram$subBrandId' in prog:
            kodiutils.addListItem(prog["description"],{'mode':'programma','sub_brand_id':prog['mediasetprogram$subBrandId']},videoInfo=infos,arts=arts)
        elif 'mediasettvseason$brandId' in prog:
            kodiutils.addListItem(prog["title"],{'mode':'programma','brand_id':prog['mediasettvseason$brandId']},videoInfo=infos,arts=arts)
        elif 'seriesId' in prog:
            kodiutils.addListItem(prog["title"],{'mode':'programma','series_id':prog['seriesId']},videoInfo=infos,arts=arts)
        else:
            kodiutils.addListItem(prog["title"],{'mode':'programma','brand_id':prog['mediasetprogram$brandId']},videoInfo=infos,arts=arts)
    kodiutils.endScript()
    
def elenco_programmi_root():
    kodiutils.addListItem("Tutti i programmi TV",{'mode':'programmitv','all':'true'})
    kodiutils.addListItem("Programmi TV in onda",{'mode':'programmitv','all':'false'})
    kodiutils.endScript()

def elenco_programmi_tutti(inonda):
    kodiutils.setContent('tvshows')
    els=mediaset.get_tv_programs_list(inonda)
    __analizza_elenco(els)

def elenco_fiction_root():
    kodiutils.setContent('videos')
    kodiutils.addListItem("Tutte le fiction",{'mode':'fiction','all':'true'})
    kodiutils.addListItem("Fiction in onda",{'mode':'fiction','all':'false'})
    for sec in mediaset.get_fiction_section_list():
        if ("uxReference" not in sec):
            continue
        kodiutils.addListItem(sec["title"],{'mode':'sezione','id':sec['uxReference']})
    kodiutils.endScript()
    
def elenco_fiction_tutti(inonda):
    kodiutils.setContent('tvshows')
    els=mediaset.get_fiction_list(inonda)
    __analizza_elenco(els)
    
def elenco_film_root():
    kodiutils.setContent('videos')
    kodiutils.addListItem("Tutti i film",{'mode':'film','all':'true'})
    for sec in mediaset.get_movie_section_list():
        if ("uxReference" not in sec):
            continue
        kodiutils.addListItem(sec["title"],{'mode':'sezione','id':sec['uxReference']})
    kodiutils.endScript()
    
def elenco_film_tutti(inonda):
    kodiutils.setContent('movies')
    els=mediaset.get_movies_list(inonda)
    __analizza_elenco(els)
    
def elenco_sezione(id):
    els=mediaset.get_section_programs(id)
    __analizza_elenco(els)

def elenco_stagioni_list(seriesId):
    els=mediaset.get_program_seasons_list(seriesId)
    __analizza_elenco(els)

def elenco_sezioni_list(brandId):
    els=mediaset.get_program_brands_list(brandId)
    els.pop(0)
    __analizza_elenco(els)

def elenco_sottosezioni_list(subBrandId):
    els=mediaset.get_program_subbrand_list(subBrandId)
    #els.pop(0)
    __analizza_elenco(els)

# workaround to gather the real url and avoid failings
def __get_real_url(url):
    res = mediaset.createRequest(url, allow_redirects=False)
    return res.headers['Location']

def playVideo(pid):
    # Play the item
    kodiutils.setResolvedUrl(__get_real_url("http://link.theplatform.eu/s/PR1GhC/media/" + pid), mtype="mpd", headers='user-agent='+useragent)
  
def playLive(id):
    # Play the item
    kodiutils.setResolvedUrl("https://link.theplatform.eu/s/PR1GhC/" + id)#, mtype="hls", headers='user-agent='+useragent)

def canali_live_root():
    els=mediaset.get_live_channels_list()
    __analizza_elenco(els)

# parameter values
params = staticutils.getParams()

if 'mode' in params:
    if params['mode'] == "programmitv":
        if 'all' in params:
            elenco_programmi_tutti(None if params['all'] == 'true' else True)
        else:
            elenco_programmi_root()
    if params['mode'] == "fiction":
        if 'all' in params:
            elenco_fiction_tutti(None if params['all'] == 'true' else True)
        else:
            elenco_fiction_root()
    if params['mode'] == "film":
        if 'all' in params:
            elenco_film_tutti(None if params['all'] == 'true' else True)
        else:
            elenco_film_root()
    if params['mode'] == "sezione":
        elenco_sezione(params['id'])
    if params['mode'] == "programma":
        if 'series_id' in params:
            elenco_stagioni_list(params['series_id'])
        elif 'sub_brand_id' in params:
            elenco_sottosezioni_list(params['sub_brand_id'])
        elif 'brand_id' in params:
            elenco_sezioni_list(params['brand_id'])
    if params['mode'] == "video":
        playVideo(params['pid'])
    if params['mode'] == "live":
        playLive(params['id'])
    if params['mode'] == "canali_live":
        canali_live_root()
else:
    root()

