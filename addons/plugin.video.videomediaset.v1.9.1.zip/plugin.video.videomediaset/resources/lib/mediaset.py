from phate89lib import rutils
import re
import math
import urllib

class Mediaset(rutils.RUtils):

    USERAGENT="VideoMediaset Kodi Addon"
    
    def __getAPISession(self):
        res = self.SESSION.get("https://api.one.accedo.tv/session?appKey=59ad346f1de1c4000dfd09c5&uuid=sdd",verify=False)
        self.setHeader('x-session',res.json()['sessionKey'])
        
    def __getAPIHeaders(self):
        data = {"cid":"dc4e7d82-89a5-4a96-acac-d3c7f2ca6d67","platform":"pc","appName":"web/mediasetplay-web/576ea90"}
        res = self.SESSION.post("https://4wfluwho22.execute-api.eu-west-1.amazonaws.com/PROD/play/idm/anonymous/login/v1.0",json=data,verify=False)        
        self.setHeader('t-apigw',res.headers['t-apigw'])
        self.setHeader('t-cts',res.headers['t-cts'])
        self.__tracecid=res.json()['response']['traceCid']
        self.__cwid=res.json()['response']['cwId']
        
    def __getResponseFromUrl(self,url,format=False):
        self.__getAPIHeaders()
        if format:
            url = url.format(traceCid=self.__tracecid,cwId=self.__cwid)
        data = self.getJson(url)
        if 'response' in data:
            return data['response']
        return data
    
    def __getEntriesFromUrl(self,url,format=False):
        return self.__getResponseFromUrl(url)['entries']
    
    def __getpagesFromUrl(self,url,page=0):
        url+= "&page={page}"
        if (page!=0):
            return self.__getEntriesFromUrl(url.format(page=page))
        els=[]
        while (True):
            page +=1
            data = self.__getResponseFromUrl(url.format(page=page))
            els.extend(data['entries'])
            if data['hasMore'] == False:
                return els
    
    def __getsectionsFromEntryID(self,id):
        self.__getAPISession()
        jsn = self.getJson("https://api.one.accedo.tv/content/entry/{id}?locale=it".format(id=id))
        id = urllib.quote(",".join(jsn["components"]))
        return self.getJson("https://api.one.accedo.tv/content/entries?id={id}&locale=it".format(id=id))['entries']
        
    def __createAZUrl(self,categories=[],inonda=None,pageels=50):
        url= "https://4wfluwho22.execute-api.eu-west-1.amazonaws.com/PROD/play/rec/azlisting/v1.0?"
        els = { "query": "*:*",
                "hitsPerPage": pageels }
        if categories:
            els["categories"] = ",".join(categories)
        if inonda != None:
            els["inOnda"] = str(inonda).lower()
        return url + urllib.urlencode(els)
    
    def get_tv_programs_list(self,inonda=None,page=0):
        self.log('Trying to get the tv program list', 4)
        return self.__getpagesFromUrl(self.__createAZUrl(["Programmi Tv"], inonda),page)
        
    def get_fiction_list(self,inonda=None,page=0):
        self.log('Trying to get the fiction list', 4)
        return self.__getpagesFromUrl(self.__createAZUrl(["Fiction"], inonda),page)
        
    def get_fiction_section_list(self):
        self.log('Trying to get the fiction sections list', 4)
        return self.__getsectionsFromEntryID("5acfcb3c23eec6000d64a6a4")
        
    def get_movies_list(self,inonda=None,page=0):
        self.log('Trying to get the movie list', 4)
        return self.__getpagesFromUrl(self.__createAZUrl(["Cinema"], inonda),page)        
        
    def get_movie_section_list(self):
        self.log('Trying to get the movie sections list', 4)
        return self.__getsectionsFromEntryID("5acfcbc423eec6000d64a6bb")
    
    def get_section_programs(self,id, page=0):
        self.log('Trying to get the programs from id ' + id, 4)
        return self.__getEntriesFromUrl("https://4wfluwho22.execute-api.eu-west-1.amazonaws.com/PROD/play/rec/cataloguelisting/v1.0?traceCid={traceCid}&platform=pc&cwId={cwId}&uxReference="+id,format=True)

    def get_program_seasons_list(self,seriesId):
        self.log('Trying to get the seasons from series id ' + seriesId, 4)
        return self.__getEntriesFromUrl("https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-tv-seasons/feed?bySeriesId={seriesId}&sort=tvSeasonNumber|desc".format(seriesId=seriesId))

    def get_program_brands_list(self,brandId):
        self.log('Trying to get the sections from brand id ' + brandId, 4)
        return self.__getEntriesFromUrl(url="https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-brands?byCustomValue={brandId}{" + brandId + "}&sort=mediasetprogram$order")
        
    def get_program_subbrand_list(self,subBrandId):
        self.log('Trying to get the sections from sub brand id ' + subBrandId, 4)
        return self.__getEntriesFromUrl(url="https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-programs?byCustomValue={subBrandId}{" + subBrandId + "}&sort=mediasetprogram$publishInfo_lastPublished|desc")
        
    def get_live_channels_list(self):
        self.log('Trying to get the live channels list', 4)
        return self.__getEntriesFromUrl('https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations?sort=ShortTitle')
